addTable <- function(D, tableType){
}