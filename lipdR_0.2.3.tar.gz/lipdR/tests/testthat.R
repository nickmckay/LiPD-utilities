library(testthat)
library(lipdR)
test_check("lipdR")
